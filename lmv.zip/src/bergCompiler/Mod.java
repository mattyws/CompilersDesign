package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Addition
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Mod extends Exp
{        
    Mod (Exp l, Exp r)
    {  super (l,r);    }
}
