package bergCompiler;
import java.util.*;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * List of Formal Parms for methods
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class FormalList <Formal> 
    extends LinkedList <Formal>
{   

}
