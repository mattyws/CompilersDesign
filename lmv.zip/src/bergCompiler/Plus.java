package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Addition
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Plus extends Exp
{        
    Plus (Exp l, Exp r)
    {  super (l,r);    }
}
