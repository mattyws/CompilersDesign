package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * Extended by all the Type classes
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public abstract class Type
{    
    Type ( )
    {  
        
    }
}
