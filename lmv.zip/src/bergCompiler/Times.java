package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Multiplication
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Times extends Exp
{        
    Times (Exp l, Exp r)
    {  super (l,r);    }
}
