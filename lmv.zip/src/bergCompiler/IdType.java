package bergCompiler;

/**
 * The various usages of an Identifier
 * @author (your name here)
 * @version (version number or date here)
 */
public enum IdType
{
    VARIABLE, METHOD, CLASS
}
