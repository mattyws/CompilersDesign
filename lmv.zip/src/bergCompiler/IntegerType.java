package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Type for int
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class IntegerType extends Type
{    
    IntegerType ( )
    {  super();    }
}
