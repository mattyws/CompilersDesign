package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Type for boolean
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class BooleanType extends Type
{    
    BooleanType ( )
    {  super();    }
}
