package bergCompiler;

/**
 * State of the lexer
 * 
 * @author (sdb)
 * @version (Jan 2011)
 */
public enum State
{
    INITIAL, ID_KEY, NUMBER, RELOP
}
