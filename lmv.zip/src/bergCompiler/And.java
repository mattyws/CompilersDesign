package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Logical And
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class And extends Exp
{        
    And (Exp l, Exp r)
    {  super (l,r);    }
}
