package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Subtraction
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Equals extends Exp
{        
    Equals (Exp l, Exp r)
    {  super (l,r);    }
}
