package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * boolean constant
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class True  extends Exp
{   

    True ( )
    {  super (null, null );     }
}
