package bergCompiler;
import java.util.*;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class ClassDeclList<ClassDecl> extends LinkedList <ClassDecl>
{

   
}
