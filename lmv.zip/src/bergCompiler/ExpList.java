package bergCompiler;
import java.util.*;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * List of Expressions
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class ExpList <Exp> 
    extends LinkedList <Exp>
{   

}
