package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Type for array of ints
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class IntArrayType extends Type
{    
    IntArrayType ( )
    {  super();    }
}
