package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Reference to this object
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class This  extends Exp
{   

    This ( )
    {  super (null, null );     }
}
