package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Addition
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Product extends Exp
{        
    Product (Exp l, Exp r)
    {  super (l,r);    }
}
