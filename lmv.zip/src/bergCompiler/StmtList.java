package bergCompiler;
import java.util.*;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * List of Statements
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class StmtList <Stmt> 
    extends LinkedList <Stmt>
{   

}
