package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Addition
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Quotient extends Exp
{        
    Quotient (Exp l, Exp r)
    {  super (l,r);    }
}
