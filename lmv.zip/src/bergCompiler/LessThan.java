package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Comparison
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class LessThan extends Exp
{        
    LessThan (Exp l, Exp r)
    {  super (l,r);    }
}
