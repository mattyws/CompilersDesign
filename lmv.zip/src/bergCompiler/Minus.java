package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * Subtraction
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class Minus extends Exp
{        
    Minus (Exp l, Exp r)
    {  super (l,r);    }
}
