package bergCompiler;

/**
 * MiniJava 
 * Abstract Syntax Trees
 * 
 * boolean constant
 * 
 * @author (sdb) 
 * @version (Jan 2011)
 */
public class False  extends Exp
{   

    False ( )
    {  super (null, null );     }
}
