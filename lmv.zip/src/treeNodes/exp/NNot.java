package treeNodes.exp;

import treeNodes.NExp;

/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */


public class NNot extends NExp {

	public NNot(NExp l) {
		super(l, null);
	}
	
	public NNot(){
		super();
	}

}
