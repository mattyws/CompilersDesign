package treeNodes;

/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */


public abstract class NType extends Node{

	public abstract String toString();
	public abstract boolean equals(Object obj);
}
