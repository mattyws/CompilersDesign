package treeNodes;

/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */


public abstract class NType extends Node{

}
