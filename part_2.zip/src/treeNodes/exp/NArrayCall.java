package treeNodes.exp;

import treeNodes.NExp;

/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */


public class NArrayCall extends NExp{
	
	public NExp exp;
	
	public NArrayCall(NExp exp) {
		super(null,null);
		this.exp=exp;
	}

}
