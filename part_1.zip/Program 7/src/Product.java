/**
 * A Product is an Expression which is the result
 * of multiplying two expressions.
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Product  extends Exp 
{
	public Product (Exp l, Exp r) {   
		left = l;
        right = r;
    }
    
    public Object accept (Visitor v) {   
    	return  v.visit (this);
    }
    
}
