/**
 * An Assign is an Expression which a value
 * is attributed to a variable.
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Assign  extends Exp 
{
	public Assign(Exp l, Exp r) {   
		left = l;
        right = r;
    }
	
	public Assign(Exp e, int i) {
		left = e;
		right = new Constant(i);
	}
    
    public Object accept(Visitor v) {   
    	return v.visit(this);
    }
    
}
