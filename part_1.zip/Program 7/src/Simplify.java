/**
 * Task:  Simplify an arithmetic expression if possible.
 * Implements Visitor.
 * Uses the Visitor pattern.
 * (This is what the optimization phase of a compiler would do)
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Simplify implements Visitor
{
    
    public Exp visit (Sum n) {  
    	return new Sum((Exp)n.left.accept(this), (Exp)n.right.accept(this));
    }
     
    public Exp visit(Difference n) {   
    	Equals eq = new Equals();
        Exp result = new Difference((Exp)n.left.accept(this), 
                 		(Exp)n.right.accept(this));
        if ((Boolean) eq.visit(result.left, result.right))        // x-x = 0
        	return new Constant(0);
        return result;
    }
    
	public Exp visit(Product n) {  
		Eval ev = new Eval();
		Exp result = new Product((Exp)n.left.accept(this), (Exp)n.right.accept(this));
		if((Integer) ev.visit(result.left) == 0 ||            // 0*x = 0
		   (Integer) ev.visit(result.right) == 0)             // x*0 = 0
			return new Constant(0);
		return result;  
	}
     
	public Exp visit(Quotient n) {  
		Equals eq = new Equals();
		Exp result = new Quotient((Exp)n.left.accept(this), (Exp)n.right.accept(this));
		if((Boolean) eq.visit(result.left, result.right))      // x/x = 1
			return new Constant(1);
		return result;
	}
	
	public Exp visit(Mod n) {  
		Equals eq = new Equals();
		Exp result = new Mod((Exp)n.left.accept(this), (Exp)n.right.accept(this));
		if((Boolean) eq.visit(result.left, result.right))     // x%x = 0
			return new Constant(0);
		return result;
	}
    
	public Exp visit(Identifier n) {  
		return new Identifier(n.name, n.value);  
	}
	
	public Exp visit(Variable n) {  
		return new Variable(n.name, n.value);  
	}
	
	public Exp visit(Assign n) {  
		return new Assign((Exp)n.left.accept(this), (Exp)n.right.accept(this));  
	}
    
    public Exp visit(Constant n) { 
        return new Constant(n.value);  
    }

    // stub, should never be called
    public Exp visit(Exp e1, Exp e2) {   
    	return null;  
    }
}