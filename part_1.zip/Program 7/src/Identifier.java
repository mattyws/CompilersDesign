/**
 * An Identifier is an Expression which has a name and a value
 * of adding two expressions.
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Identifier extends Exp 
{
	String name;
	Integer value;
	
	public Identifier(String s) {   
		name = s;
    }
	
	public Identifier(String s, Integer i) {   
		name = s;
		value = i;
    }
    
    public Object accept(Visitor v) {   
    	return  v.visit(this);
    }
    
    public void setValue(Object o) {
    	value = (Integer) o;
    }
    
    public Integer getValue() {
    	return value;
    }
    
}
