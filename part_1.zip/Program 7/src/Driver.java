/**
 * Test the Expression interpreter.
 *  
 * Uses the Visitor pattern
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */

public class Driver
{   public static void main(String args[])
    {   
	
		//Test variable and assign
		System.out.println("Testing variable and assign");
		Exp a = new Variable("a");
	    Exp assign = new Assign(a, 17);     // a = 17
	    Visitor intrp = new Eval();           // A Visitor which evaluates an expression tree
	    try {   
	    	intrp.visit((Variable) a);  	// An Exception is thrown
	    } catch (Exception e) { 
	    	System.out.println ("Variable \"" + ((Variable) a).name + "\" does not have a value.");  
	    }           
	    intrp.visit((Assign) assign);
	    intrp.visit((Variable) a);                      // No Exception is thrown
	    
	    //Test toStr
	    System.out.println("\nTesting toStr");
	    Exp b = new Variable ("b");
	    Exp e = new Quotient (a, new Sum (b, new Constant (2)));        // e =  a / (b+2)
	    Visitor toStr = new ToString();
	    System.out.println(toStr.visit((Quotient) e));
	    
	    //Test Sum and Difference
	    System.out.println("\nTesting sum and difference");
        Exp e1 = new Constant(3);
        Exp e2 = new Sum(e1,new Constant(2));                      //3+2
        intrp = new Eval();
        Difference diff = new Difference (e2, new Constant (2));   // (3+2)-2
        System.out.println(toStr.visit(diff) + " = " +intrp.visit (diff));
        
        Simplify simple = new Simplify();
        Exp e3 = simple.visit(diff);
        
        Exp e4 = new Sum (new Constant(2), new Constant(3));       //2+3
        Equals eq = new Equals();
        System.out.println ("3+2 == 2+3: " + eq.visit (e2, e4));
        
        diff = new Difference (e2, e4);
        Exp e5 = simple.visit(diff);     
        System.out.println(toStr.visit((Constant) e5));
        
        //Test Product
        System.out.println("\nTesting product");
        Variable v = new Variable("v");
        assign = new Assign(v, 12);               //v = 12
        intrp = new Eval();
        intrp.visit((Assign) assign);
        Product p1 = new Product(v, new Constant(9));     //12 * 9
        System.out.println(toStr.visit(p1) + " = " + intrp.visit(p1));
        Product p2 = new Product(new Constant(0), e2);   //0 * (3+2)
        System.out.println(toStr.visit(p1));
        e1 = simple.visit(p2);                  //0
        System.out.println(toStr.visit((Constant) e1));
        
        //Test Quotient
        System.out.println("\nTesting quotient");
        Quotient q1 = new Quotient(e2, e4);     //(3+2) / (2+3)
        System.out.println(toStr.visit(q1) + " = " + intrp.visit(q1));
        e1 = simple.visit(q1);                  //1
        System.out.println(toStr.visit((Constant) e1));
        
        //Test Mod
        System.out.println("\nTesting mod");
        Mod m1 = new Mod(e2, e4);     //(3+2) / (2+3)
        System.out.println(toStr.visit(m1) + " = " + intrp.visit(m1));
        e1 = simple.visit(m1);                  //0
        System.out.println(toStr.visit((Constant) e1));
        
        //Combined tests
        System.out.println("\nCombined test");
        q1 = new Quotient(p1, e2);       //(12*9) / (3+2)
        System.out.println(toStr.visit(q1) + " = " + intrp.visit(q1));
        m1 = new Mod(v, e2);            //12 % (3+2)
        System.out.println(toStr.visit(m1) + " = " + intrp.visit(m1));
        q1 = new Quotient(p1, new Product(m1, new Constant(7)));  //(12*9) / ((12 % (3+2))*7)
        System.out.println(toStr.visit(q1) + " = " + intrp.visit(q1));
        m1 = new Mod(p1, new Product(m1, new Constant(7)));  //(12*9) % ((12 % (3+2))*7)
        System.out.println(toStr.visit(m1) + " = " + intrp.visit(m1));
    }
}
        
