/**
 * A Mod is an Expression which is the remainder
 * of the division between two expressions.
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Mod  extends Exp 
{
	public Mod (Exp l, Exp r) {   
		left = l;
        right = r;
    }
    
    public Object accept (Visitor v) {   
    	return  v.visit (this);
    }
    
}
