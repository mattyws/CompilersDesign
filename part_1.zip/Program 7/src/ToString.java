/**
 * Task: Return a String representation of the given expression.
 * Implements Visitor.
 * Uses the Visitor pattern.
 * (This is what an interpreter would do, not a compiler)
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class ToString implements Visitor    
{
     public String visit (Sum n) {  
    	 return "(" + (String) n.left.accept(this) + " + " + (String) n.right.accept(this) + ")";
     }
     
     public String visit (Difference n) {  
    	 return "(" + (String) n.left.accept(this) + " - " + (String) n.right.accept(this) + ")"; 
     }
    
	public String visit (Product n) {  
		return "(" + (String) n.left.accept(this) + " * " + (String) n.right.accept(this) + ")";  
	}
     
	public String visit (Quotient n) {  
		return "(" + (String) n.left.accept(this) + " / " + (String) n.right.accept(this) + ")";  
	}
	
	public String visit (Mod n) {  
		return "(" + (String) n.left.accept(this) + " % " + (String) n.right.accept(this) + ")";  
	}
     
	public String visit (Identifier n) {  
		return n.name;  
	}
	
	public String visit (Variable n) {  
		return n.name;  
	}
	
	public String visit (Assign n) {  
		return (String) n.left.accept(this) + " = " + (String) n.right.accept(this);
    }
    
    public String visit (Constant n) { 
        return String.valueOf(n.value);  
    }
    
    // stub, should never be called
    public Exp visit (Exp e1, Exp e2) {   
    	return null;  
    }
}