/**
 * Task:  Evaluate an arithmetic expressions.
 * Implements Visitor.
 * Uses the Visitor pattern.
 * (This is what an interpreter would do, not a compiler)
 * 
 * @author Vitor Finati, Lucas Gabriel, Mattyws Ferreira
 * @version (Apr 2016)
 */
public class Eval implements Visitor    
{
     public Integer visit (Sum n) {  
    	 return (Integer) n.left.accept(this) + (Integer) n.right.accept (this);
     }
     
     public Integer visit (Difference n) {  
    	 return (Integer) n.left.accept(this) - (Integer) n.right.accept (this); 
     }
    
	public Integer visit (Product n) {  
		return (Integer) n.left.accept(this) * (Integer) n.right.accept(this);  
	}
     
	public Integer visit (Quotient n) {  
		return (Integer) n.left.accept(this) / (Integer) n.right.accept(this);  
	}
	
	public Integer visit (Mod n) {  
		return (Integer) n.left.accept(this) % (Integer) n.right.accept(this);  
	}
     
	public Integer visit (Identifier n) {  
		return n.getValue();  
	}
	
	public Integer visit (Variable n) { 
		if(n.getValue() == null)
			throw new NullPointerException();
		return n.getValue();  
	}
	
	public Integer visit (Assign n) {  
    	((Variable) (n.left)).setValue(n.right.accept(this));
    	return (Integer) n.right.accept(this); 
    }
    
    public Integer visit (Constant n) { 
        return n.value;  
    }
    
    // stub, should never be called
    public Exp visit (Exp e1, Exp e2) {   
    	return null;  
    }
    
	public Integer visit (Exp e) {  
		Integer result = null;
		if(e instanceof Sum)
			result = visit((Sum) e);
		else if(e instanceof Difference)
			result = visit((Difference) e);
		else if(e instanceof Product)
			result = visit((Product) e);
		else if(e instanceof Quotient)
			result = visit((Quotient) e);
		else if(e instanceof Mod)
			result = visit((Mod) e);
		else if(e instanceof Identifier)
			result = visit((Identifier) e);
		else if(e instanceof Variable)
			result = visit((Variable) e);
		else if(e instanceof Constant)
			result = visit((Constant) e);
		return result;
	}
}