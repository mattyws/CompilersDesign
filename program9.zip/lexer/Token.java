package lexer;
/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */
public abstract class Token {
	
	public String token;

	public abstract String getToken();
}
