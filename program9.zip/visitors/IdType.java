package visitors;

/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */

public enum IdType
{
    VARIABLE, METHOD
}
