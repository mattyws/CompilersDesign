package lexer;
/**
 * 
 * @author Lucas Menezes, Mattyws Grawe, Vitor Finati
 *
 */
public class TokenChar extends Token{
	
	public TokenChar(String token) {
		this.token=token;
	}

	@Override
	public String getToken() {
		return token;
	}

}
